def diaDoProgramador(ano):
    if ano == 1918:
        return "26.09.1918"
    elif ano < 1918:
        if ano % 4 == 0:
            return f"12.09.{ano}"
        else:
            return f"13.09.{ano}"

    else:
        if (ano % 4 == 0 and ano % 100 != 0) or ano % 400 == 0:
            return f"12.09.{ano}"
        else:
            return f"13.09.{ano}"


def main():
    ano = int(input("Digite o ano desejado (valor inteiro entre 1700 e 2700 por favor): "))
    while not(1700 <= ano <= 2700):
        print("Ano inválido!\n")
        ano = int(input("Digite o ano desejado (valor inteiro entre 1700 e 2700 por favor): "))

    print(diaDoProgramador(ano))


main()
